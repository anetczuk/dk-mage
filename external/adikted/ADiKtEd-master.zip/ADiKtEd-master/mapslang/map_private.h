/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef MAP_PRIVATE_H
#define MAP_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"0.9.6.68"
#define VER_MAJOR	0
#define VER_MINOR	9
#define VER_RELEASE	6
#define VER_BUILD	68
#define COMPANY_NAME	""
#define FILE_VERSION	""
#define FILE_DESCRIPTION	"Adikted Dungeon Keeper map editor"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	"public domain"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"Bullfrog unofficial game tools"
#define PRODUCT_VERSION	""

#endif /*MAP_PRIVATE_H*/
