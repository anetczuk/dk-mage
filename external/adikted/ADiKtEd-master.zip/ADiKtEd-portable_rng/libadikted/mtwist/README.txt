Source code of Mersenne Twist Pseudorandom Number Generator Package was taken from https://www.cs.hmc.edu/~geoff/mtwist.html
Version: 1.5
The code is published under LGPL license.
