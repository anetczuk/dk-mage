/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef ADIKTED_PRIVATE_H
#define ADIKTED_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"0.9.6.1"
#define VER_MAJOR	0
#define VER_MINOR	9
#define VER_RELEASE	6
#define VER_BUILD	1
#define COMPANY_NAME	""
#define FILE_VERSION	""
#define FILE_DESCRIPTION	"ADiKtEd Map Maintain Library"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	"GNU General Public License v2.0"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"Another Dungeon Keeper Editor"
#define PRODUCT_VERSION	""

#endif /*ADIKTED_PRIVATE_H*/
